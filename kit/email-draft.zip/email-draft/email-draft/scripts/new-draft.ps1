param(
  [Parameter(Mandatory=$true)][string]$Subject,
  [string]$BodyFile = "",
  [string]$BodyHtml = "",
  [string]$To = "",
  [string]$Signature = "",
  [switch]$NoSignature,
  [string[]]$Attach = @(),
  [string]$Account = ""
)
$ErrorActionPreference = 'Stop'

# ============================================================
#  SAFETY INVARIANT - DO NOT REMOVE
#  This script ONLY creates a DRAFT and calls .Save().
#  It MUST NEVER call .Send(). Only the owner sends, by hand, from Outlook.
#  Never add .Send() to this file, for any reason, in any environment.
# ============================================================

# ============================================================
#  DEFAULT STYLE - edit these to match your own house style.
#  These apply to every draft this script creates, until you change them again.
#  (The values below are a starting template, not a requirement.)
# ============================================================
$DefaultFont               = "Arial"     # font family
$DefaultFontSizePt         = 12          # point size
$DefaultDirection          = "RTL"       # "RTL" or "LTR"
$DefaultAlign              = "right"     # "right" or "left" (usually matches direction)
$DefaultLineSpacingPercent = 150         # 150 = Word/Outlook "1.5 lines"; 100 = single spacing

if ($BodyHtml -eq "" -and $BodyFile -eq "") { throw "Provide -BodyHtml or -BodyFile" }
if ($BodyFile -ne "" -and -not (Test-Path $BodyFile)) { throw "BodyFile not found: $BodyFile" }
$inner = if ($BodyHtml -ne "") { $BodyHtml } else { Get-Content -Path $BodyFile -Raw -Encoding UTF8 }

# signature: -NoSignature wins; else -Signature; else signature.html next to this script; else none
$sigText = ""
if (-not $NoSignature) {
    if ($Signature -ne "") {
        $sigText = $Signature
    } else {
        $sigFile = Join-Path $PSScriptRoot 'signature.html'
        if (Test-Path $sigFile) { $sigText = (Get-Content -Path $sigFile -Raw -Encoding UTF8).Trim() }
    }
}
$sig = ""
if ($sigText -ne "") { $sig = "<br><br>" + $sigText }

# --- house style, built from the DEFAULT STYLE block above ---
# IMPORTANT: for 1.5 spacing to render as Word/Outlook's real "1.5 lines" rule, it MUST come out
# as line-height:<percent>% on an HTML paragraph, NOT as CSS line-height:1.5 (unitless) on a <div>.
# The unitless CSS value does not map to Word's paragraph spacing rule and renders as single/exact
# spacing instead. See CONTEXT-PACK.md section 8 before changing this block.
$dirAttr = if ($DefaultDirection -eq "RTL") { "RTL" } else { "LTR" }
$cssDir  = if ($DefaultDirection -eq "RTL") { "rtl" } else { "ltr" }
$open = "<p dir={0} style='margin:0;text-align:{1};line-height:{2}%;direction:{3};unicode-bidi:embed'><span style='font-size:{4}.0pt;font-family:`"{5}`",sans-serif'>" -f `
    $dirAttr, $DefaultAlign, $DefaultLineSpacingPercent, $cssDir, $DefaultFontSizePt, $DefaultFont
$close = "</span></p>"
$html  = $open + $inner + $sig + $close

$ol = New-Object -ComObject Outlook.Application
$mail = $ol.CreateItem(0)   # olMailItem
$mail.Subject  = $Subject
$mail.To       = $To
$mail.HTMLBody = $html

if ($Account -ne "") {
    try {
        foreach ($acc in $ol.Session.Accounts) {
            if ($acc.SmtpAddress -eq $Account -or $acc.DisplayName -eq $Account) { $mail.SendUsingAccount = $acc; break }
        }
    } catch {}
}

$attCount = 0
foreach ($att in $Attach) {
    if ($att -eq "") { continue }
    if (Test-Path $att) {
        [void]$mail.Attachments.Add((Resolve-Path $att).Path)
        $attCount++
    } else {
        Write-Output ("ATTACH_MISSING: " + $att)
    }
}

$mail.Save()   # Drafts only. NEVER .Send().

Write-Output "DRAFT_SAVED"
Write-Output ("Subject: " + $mail.Subject)
Write-Output ("To:      " + $mail.To)
Write-Output ("Attach:  " + $attCount)
Write-Output ("Folder:  " + $mail.Parent.Name)
Write-Output ("Store:   " + $mail.Parent.Store.DisplayName)
Write-Output ("EntryID: " + $mail.EntryID)
