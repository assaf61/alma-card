# -*- coding: utf-8 -*-
"""
verify_xl.py - אימות מכני של תרגום אקסל גדול (שלב 7 של xl-translate).

שימוש:
    python verify_xl.py <original.xlsx> <translated.xlsx> [--src-cols A,B] [--target-col C] [--glossary glossary.md]

בודק:
  1. מספר שורות זהה וסדר נשמר (לפי עמודת המפתח הראשונה).
  2. עמודות המקור זהות ביט-לביט למקור.
  3. עמודת היעד מלאה (אפס תאים ריקים בשורות שיש בהן מקור).
  4. אם ניתן מילון: דגימת עקביות, מונח-עוגן שמופיע בעברית ביותר מצורה אחת מסומן.

יציאה 0 = עבר. יציאה 1 = כשל, עם פירוט.
"""
import sys, io, argparse, re, collections

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

try:
    from openpyxl import load_workbook
except ImportError:
    print("חסר openpyxl. התקנה: pip install openpyxl")
    sys.exit(1)


def col_letters_to_idx(letters):
    return [ord(c.upper()) - ord('A') for c in letters.split(',')]


def read_rows(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    return [[c.value for c in row] for row in ws.iter_rows()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("original")
    ap.add_argument("translated")
    ap.add_argument("--src-cols", default="A,B", help="עמודות מקור שאסור שישתנו")
    ap.add_argument("--target-col", default="C", help="עמודת התרגום")
    ap.add_argument("--glossary", default=None, help="קובץ מילון-עוגן לדגימת עקביות")
    args = ap.parse_args()

    src_idx = col_letters_to_idx(args.src_cols)
    tgt_idx = col_letters_to_idx(args.target_col)[0]

    orig = read_rows(args.original)
    trans = read_rows(args.translated)
    fails = []

    # 1. שורות
    if len(orig) != len(trans):
        fails.append(f"מספר שורות: מקור {len(orig)}, תרגום {len(trans)}")

    # 2. עמודות מקור + 3. כיסוי יעד
    empty_targets = []
    for i, (o, t) in enumerate(zip(orig, trans), start=1):
        for ci in src_idx:
            ov = o[ci] if ci < len(o) else None
            tv = t[ci] if ci < len(t) else None
            if ov != tv:
                fails.append(f"שורה {i}, עמודה {chr(ord('A')+ci)}: מקור השתנה ({ov!r} -> {tv!r})")
                if len(fails) > 20:
                    break
        src_has = any((o[ci] not in (None, "")) for ci in src_idx if ci < len(o))
        tv = t[tgt_idx] if tgt_idx < len(t) else None
        if src_has and (tv is None or str(tv).strip() == ""):
            empty_targets.append(i)
        if len(fails) > 20:
            break
    if empty_targets:
        fails.append(f"עמודת יעד ריקה ב-{len(empty_targets)} שורות (ראשונות: {empty_targets[:10]})")

    # 4. דגימת עקביות עוגנים
    if args.glossary:
        try:
            gl = open(args.glossary, encoding="utf-8").read()
            anchors = re.findall(r'"([^"]+)"\s*=\s*"([^"]+)"', gl) + \
                      re.findall(r'=\s*([֐-׿][^;\n(]{2,30})', gl)
            he_terms = set()
            for a in anchors:
                he_terms.add(a[1].strip() if isinstance(a, tuple) else a.strip())
            body = "\n".join(str(r[tgt_idx]) for r in trans if tgt_idx < len(r) and r[tgt_idx])
            variants = collections.Counter()
            for term in list(he_terms)[:40]:
                if len(term) < 4:
                    continue
                stem = term[:-1]
                forms = set(re.findall(re.escape(stem) + r"[֐-׿]{0,2}", body))
                if len(forms) > 3:
                    variants[term] = len(forms)
            if variants:
                print("אזהרת עקביות (לא חוסם): מונחים עם צורות רבות:",
                      ", ".join(f"{t} ({n})" for t, n in variants.most_common(5)))
        except Exception as e:
            print("דגימת מילון דולגה:", e)

    if fails:
        print("אימות נכשל:")
        for f in fails[:25]:
            print(" -", f)
        sys.exit(1)
    print(f"אימות עבר: {len(trans)} שורות, עמודות מקור נקיות, יעד מלא.")
    sys.exit(0)


if __name__ == "__main__":
    main()
