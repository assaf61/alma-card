# -*- coding: utf-8 -*-
# בונה קובץ כתוביות ASS בסגנון המאושר: קנבס 9:16 (1080x1920), הווידאו למעלה,
# והעברית בפס תחתון נפרד, מעוגנת-למעלה מיד מתחת לווידאו וגבוה מהקצה.
#
# שימוש: python build_ass.py <segments.json> <hebrew.json> <out.ass> [font]
#   segments.json : פלט transcribe.py (רשימת {i,start,end,src})
#   hebrew.json   : רשימת JSON של מחרוזות עברית, מיושרות 1:1 לפי סדר לקטעים
#   out.ass       : נתיב פלט (ברירת מחדל sub.ass)
#   font          : שם גופן (ברירת מחדל Arial; אפשר גופן עברי אחר אם מותקן, למשל Heebo)
#
# קטע ארוך (>58 תווים) מפוצל אוטומטית לשתי כתוביות לפי זמן, כדי שהטקסט יישאר
# עד ~2 שורות ולא ייגרר נמוך אל הקצה.
import sys, io, json

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

seg_path = sys.argv[1] if len(sys.argv) > 1 else "segments.json"
he_path = sys.argv[2] if len(sys.argv) > 2 else "hebrew.json"
out_path = sys.argv[3] if len(sys.argv) > 3 else "sub.ass"
FONT = sys.argv[4] if len(sys.argv) > 4 else "Arial"

RLM = "‏"  # Right-to-Left Mark: מקבע כיווניות RTL לכל שורה
MAXCHARS = 58

segs = json.load(open(seg_path, encoding="utf-8"))
he = json.load(open(he_path, encoding="utf-8"))
assert len(segs) == len(he), "count mismatch: %d segs vs %d he" % (len(segs), len(he))

def ts(t):
    if t < 0: t = 0
    h = int(t // 3600); t -= h * 3600
    m = int(t // 60); t -= m * 60
    s = int(t); cs = int(round((t - s) * 100))
    if cs == 100: cs = 0; s += 1
    return "%d:%02d:%02d.%02d" % (h, m, s, cs)

def split(a, b, text, depth=0):
    text = text.strip()
    if len(text) <= MAXCHARS or depth >= 2 or " " not in text:
        return [(a, b, text)]
    mid = len(text) // 2
    l = text.rfind(" ", 0, mid); r = text.find(" ", mid)
    idx = l if (mid - l) <= (r - mid) and l > 0 else (r if r > 0 else l)
    if idx <= 0:
        return [(a, b, text)]
    x, y = text[:idx].strip(), text[idx + 1:].strip()
    t = a + (b - a) * len(x) / max(1, len(x) + len(y))
    return split(a, t, x, depth + 1) + split(t, b, y, depth + 1)

# Encoding=177 (Hebrew) עוזר לחלק מנועי רינדור לבחור גלִיפים עבריים.
# Alignment=8 (מעוגן-למעלה) + \pos מציב את הטקסט מיד מתחת לתפר הווידאו.
header = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 0
ScaledBorderAndShadow: yes
YCbCr Matrix: TV.709

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Heb,%s,52,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,2,0,8,60,60,40,177
""" % FONT

POS = "{\\an8\\pos(540,1585)}"  # תפר הווידאו ב-y=1560; הטקסט מתחתיו מיד

lines = [header, "[Events]",
         "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"]
n = 0
for seg, h in zip(segs, he):
    for a, b, txt in split(seg["start"], seg["end"], h):
        if not txt:
            continue
        lines.append("Dialogue: 0,%s,%s,Heb,,0,0,0,,%s%s%s" % (ts(a), ts(b), POS, RLM, txt))
        n += 1

open(out_path, "w", encoding="utf-8").write("\n".join(lines) + "\n")
print("wrote", out_path, "with", n, "dialogue lines from", len(segs), "segments")
