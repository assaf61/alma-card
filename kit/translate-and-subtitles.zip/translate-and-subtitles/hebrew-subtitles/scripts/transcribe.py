# -*- coding: utf-8 -*-
# תמלול מדיה לקטעים עם חותמות-זמן, בעזרת faster-whisper.
# שימוש: python transcribe.py <media_path> <source_lang|auto> <out_json>
#   media_path : קובץ וידאו או אודיו (mp4 / m4a / wav ...)
#   source_lang: קוד שפת המקור ("es","en","ar","ru"...) או "auto" לזיהוי אוטומטי
#   out_json   : נתיב פלט JSON (ברירת מחדל segments.json)
#
# עיקרון קריטי: שומרים start/end לכל קטע בנפרד. אין לאחד הכל למחרוזת אחת -
# זה מאבד את התזמון והכתוביות לא יסתנכרנו.
import sys, io, json
from faster_whisper import WhisperModel

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

media = sys.argv[1]
lang = sys.argv[2] if len(sys.argv) > 2 else "auto"
out = sys.argv[3] if len(sys.argv) > 3 else "segments.json"
if lang.lower() in ("auto", "", "none"):
    lang = None

# small + int8 על CPU: איזון טוב בין דיוק למהירות. ~500MB הורדה חד-פעמית.
model = WhisperModel("small", device="cpu", compute_type="int8")
segments, info = model.transcribe(media, language=lang, vad_filter=True)

segs = []
for s in segments:
    segs.append({"i": len(segs) + 1, "start": round(s.start, 3), "end": round(s.end, 3), "src": s.text.strip()})
    print("%3d | %7.2f -> %7.2f | %s" % (segs[-1]["i"], segs[-1]["start"], segs[-1]["end"], segs[-1]["src"]))

json.dump(segs, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("TOTAL_SEGMENTS", len(segs), "LANG", info.language, "DUR", round(info.duration, 1))
