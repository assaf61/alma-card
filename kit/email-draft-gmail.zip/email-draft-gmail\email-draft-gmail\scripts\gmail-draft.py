#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gmail-draft.py - מכין טיוטת מייל ב-Gmail: פותח חלון כתיבה מלא ומוכן בדפדפן.

חוק הברזל: הכלי לעולם לא שולח. הוא פותח את חלון הכתיבה של Gmail עם הכל ממולא,
והאדם עובר בעיניים ולוחץ שליחה בעצמו (או סוגר). אין בקוד שום נתיב שליחה,
ואסור להוסיף כזה - לא Gmail API, לא אוטומציית דפדפן, שום דבר. ראה SETUP.md.

שימוש:
  python gmail-draft.py --subject "נושא" --body-file body.txt [--to addr] [--cc addr]
                        [--account 0] [--print-url]

הערות:
- הגוף הוא טקסט פשוט (UTF-8), לא HTML. Gmail מזהה עברית ומיישר RTL לבד,
  ומוסיף את החתימה שמוגדרת אצלך ב-Gmail.
- חלון כתיבה פתוח נשמר אוטומטית כטיוטה ב-Drafts של Gmail.
- גוף ארוך: לדפדפנים יש תקרת אורך URL. מעל הסף הסקריפט מעתיק את הגוף ללוח,
  פותח את החלון עם נמען+נושא בלבד, ואומר להדביק (Ctrl+V).
- --account N בוחר חשבון Gmail כשמחוברים לכמה (0 = הראשון).
"""
import argparse
import subprocess
import sys
import urllib.parse
import webbrowser

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

MAX_URL = 1900  # safe floor across browsers; above it the body moves to the clipboard


def copy_clipboard(text):
    if sys.platform.startswith("win"):
        try:
            p = subprocess.Popen(["clip"], stdin=subprocess.PIPE)
            p.communicate(text.encode("utf-16-le"))  # clip.exe expects UTF-16LE
            return p.returncode == 0
        except Exception:
            return False
    for cmd in (["pbcopy"], ["xclip", "-selection", "clipboard"], ["xsel", "-b"]):
        try:
            p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
            p.communicate(text.encode("utf-8"))
            if p.returncode == 0:
                return True
        except FileNotFoundError:
            continue
        except Exception:
            return False
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--to", default="")
    ap.add_argument("--cc", default="")
    ap.add_argument("--subject", required=True)
    ap.add_argument("--body-file", required=True)
    ap.add_argument("--account", default="0", help="Gmail account index when signed into several (u/N)")
    ap.add_argument("--print-url", action="store_true", help="הדפס את הקישור במקום לפתוח דפדפן")
    a = ap.parse_args()

    with open(a.body_file, encoding="utf-8-sig") as f:
        body = f.read().strip()

    q = urllib.parse.quote
    base = f"https://mail.google.com/mail/u/{a.account}/?view=cm&fs=1"
    if a.to:
        base += "&to=" + q(a.to)
    if a.cc:
        base += "&cc=" + q(a.cc)
    base += "&su=" + q(a.subject)
    url = base + "&body=" + q(body)

    note = "COMPOSE_READY"
    if len(url) > MAX_URL:
        url = base
        if copy_clipboard(body):
            note = "BODY_TO_CLIPBOARD: הגוף ארוך מקישור, הועתק ללוח. בחלון שנפתח הדבק עם Ctrl+V."
        else:
            note = f"BODY_TOO_LONG: העתק ידנית את הגוף מהקובץ {a.body_file} והדבק בחלון."

    if a.print_url:
        print(url)
    else:
        webbrowser.open(url)
        print("OPENED: חלון כתיבה של Gmail נפתח בדפדפן. עבור בעיניים ושלח בעצמך, או סגור.")
    print(note)
    return 0


if __name__ == "__main__":
    sys.exit(main())
