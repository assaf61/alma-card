@echo off
rem Double-click this file to install the tool. It just runs the PowerShell installer next to it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
