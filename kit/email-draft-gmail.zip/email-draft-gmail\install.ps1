# Universal self-installer for Alma tool packages.
# ASCII-only by design: every Hebrew string shown to the user comes from pack.json (read as UTF-8),
# so the message text never depends on how PowerShell decodes this .ps1 file.
$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms | Out-Null

    $here = Split-Path -Parent $MyInvocation.MyCommand.Path
    $packPath = Join-Path $here 'pack.json'
    $json = [System.IO.File]::ReadAllText($packPath, [System.Text.Encoding]::UTF8)
    $pack = $json | ConvertFrom-Json
    $ui = $pack.ui

    function Show-Msg($text, $icon) {
        [System.Windows.Forms.MessageBox]::Show($text, $ui.title,
            [System.Windows.Forms.MessageBoxButtons]::OK, $icon) | Out-Null
    }

    # A skill is a Claude Code add-on; without Claude Code there is nowhere to install it.
    $claude = Join-Path $env:USERPROFILE '.claude'
    if (-not (Test-Path $claude)) {
        Show-Msg $ui.noClaude ([System.Windows.Forms.MessageBoxIcon]::Warning)
        return
    }

    $skillsDir = Join-Path $claude 'skills'
    New-Item -ItemType Directory -Force -Path $skillsDir | Out-Null

    $lines = @()
    $warns = @()

    foreach ($s in $pack.skills) {
        $src = Join-Path $here $s.folder
        $dest = Join-Path $skillsDir $s.skillName
        New-Item -ItemType Directory -Force -Path $dest | Out-Null

        # Copy-Item is Unicode-path safe (unlike handing paths to native robocopy).
        Copy-Item -Path (Join-Path $src '*') -Destination $dest -Recurse -Force

        # Opportunistic, never-fatal dependency install (small pure-python packages only).
        if ($s.pip) {
            $py = Get-Command python -ErrorAction SilentlyContinue
            if ($py) {
                foreach ($pkg in $s.pip) {
                    try {
                        & python -m pip install --quiet --disable-pip-version-check $pkg 2>$null | Out-Null
                    } catch { }
                }
            }
        }

        # Detect heavier prerequisites we do NOT auto-install, and report them plainly.
        if ($s.requires) {
            foreach ($req in $s.requires) {
                if (-not (Get-Command $req.cmd -ErrorAction SilentlyContinue)) {
                    if ($warns -notcontains $req.missingText) { $warns += $req.missingText }
                }
            }
        }

        $line = $s.installedText -replace '\{trigger\}', $s.trigger
        if ($s.note) { $line = $line + "`n(" + $s.note + ")" }
        $lines += $line
    }

    $msg = $ui.successIntro + "`n`n" + ($lines -join "`n`n")
    if ($warns.Count -gt 0) {
        $msg += "`n`n" + $ui.warnIntro + "`n- " + ($warns -join "`n- ")
    }
    $msg += "`n`n" + $ui.outro
    Show-Msg $msg ([System.Windows.Forms.MessageBoxIcon]::Information)
}
catch {
    # Rare crash path: keep it ASCII so it shows even if pack.json failed to load.
    try {
        Add-Type -AssemblyName System.Windows.Forms | Out-Null
        [System.Windows.Forms.MessageBox]::Show(
            ("Install error:`n" + $_.Exception.Message + "`n`nPlease send this line to Assaf and we will fix it together."),
            "Alma installer", 0, 16) | Out-Null
    } catch {
        Write-Host ("Install error: " + $_.Exception.Message)
    }
}
